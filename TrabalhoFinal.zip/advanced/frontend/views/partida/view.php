<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\DetailView;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $model common\models\Partida */

//$this->title = $model->user1->username . " X ";
//$this->title .= $model->user2?$model->user2->username:"...";
$this->params['breadcrumbs'][] = ['label' => 'Partidas', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

// Insiro os estilos CSS criados para a aplicação feita em javascript
//$this->registerCssFile('css/estilos.css');

// Carrego o javascript do jogo
/*$this->registerJsFile('js/gmk.js');

if (!$vencedor) {
$this->registerJs('
    setInterval(function() {
        recarregar = document.getElementById("recarregar");
        recarregar.click();
    }, 1000);
');
}*/

?>

<?php // Pjax::begin(); ?>
<div class="partida-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <!-- ADICIONAR: DetailView contendo os participantes do jogo -->
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            [
                'attribute'=>'id_user_1',
                'label'=>'<img id="jogador_1" src="img/1.gif" width=20 /> Jogador 1',
                'value'=>$model->user1->username,

                ],
            [

                'attribute'=>'id_user_2',
                'label'=>'<img id="jogador_2" src="img/2.gif" width=20 /> Jogador 2',
                'value'=>$model->user2?$model->user2->username:"Aguardando jogador ...",
            ],
            [
                'attribute'=>'vencedor',
                'value'=>$model->vencedor?$model->vencedor0->username: "Vencedor não definido"
            ],
            ],
        ])

    ?>

    <!-- Link usado pelo Pjax, para carregar o tabuleiro a cada segundo -->
    <?= //Html::a('Recarregar',['partida/view','id'=>$model->id],['id'=>'recarregar','style'=>'display:none']) ?>

    <div class="container">
        <table style ="float:left">
        <table class='tabuleiro'>
            <?php
                for ($row=0; $row <15 ; $row++) { 
                    echo "<tr>";
                    for ($col=0; $col < 15 ; $col++) { 
                        $url = Url::to(['partida/view','id'=>$model=>id,'linha'=>$row,'coluna'=>$col]);
                        if ($vencedor != 0) {
                            if ($jogadas[$row][$col] == $model->id_user_1) {
                                echo "<td><img src='img/1.gif' width=32 /></td>";  
                                # code...
                            } else if ($jogadas[$row][$col] == $model->id_user_2){
                                echo "<td><img src='img/2.gif' width=32 /></td>";
                            } else{
                               echo "<td><img src='img/0.gif' width=32 /></td>"; 
                            }
                        }
                        else if ($jogador_da_vez == Yii::$app->user->id) {
                            echo "<td id='c_ " . $row . "_" . $col . "'><a href='".$url."'onClick='Clicked(" . $row . "," . $col . "," . Yii::$app->user->id.")'> <img src = 'img/0.gif' width = 32 /> </a> </td>";
                            # code...
                        } else {
                            echo "<td id='c_ " . $row . "_" . $col . "'><img src='img/0.gif' width=32/></td>";
                        }

                        if ($jogadas[$row][$col]!=0) {
                            $this->registerJs("Clicked(" . $row . "," . $col . "," . $jogadas[$row][$col] . ");");
                            # code...
                        }
                    }
                    echo "</tr>";
                }
            ?>
        </table>

    </div>    

</div>
<?php //Pjax::end(); ?>
